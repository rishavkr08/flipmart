(function() {
  this.test = function() {
    $('.alert').show();
  };

}).call(this);
